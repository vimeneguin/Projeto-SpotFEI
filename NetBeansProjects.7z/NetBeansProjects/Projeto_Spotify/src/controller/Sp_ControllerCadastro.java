/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DAO.UsuarioDAO;
import DAO.Sp_Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Usuario;
import view.Sp_CadastroFrame;
/**
 *
 * @author unicvmeneguin
 */
public class Sp_ControllerCadastro {
    private Sp_CadastroFrame view;

    public Sp_ControllerCadastro(Sp_CadastroFrame view) {
        this.view = view;
    }
    
    public void salvarUsuario(){
        String nome = view.getTxt_nome_cadastro().getText();
        String usuario = view.getTxt_usuario_cadastro().getText();
        String senha = view.getTxt_senha_cadastro().getText();
        Usuario usuario = new Usuario(nome, usuario, senha);
        Sp_Conexao conexao = new Sp_Conexao();
        try{
            Connection conn = conexao.getConnection();
            UsuarioDAO dao = new UsuarioDAO(conn);
            dao.inserir(usuario);
            JOptionPane.showMessageDialog(view, "Usuário cadastrado.");
        } catch (SQLException e){
            JOptionPane.showMessageDialog(view, "Erro de conexão.");
        }
    }
}
