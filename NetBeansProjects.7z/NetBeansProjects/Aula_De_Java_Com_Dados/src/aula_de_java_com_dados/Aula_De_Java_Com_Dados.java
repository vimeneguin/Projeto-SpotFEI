/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula_de_java_com_dados;

import view.LoginFrame;

/**
 *
 * @author unicvmeneguin
 */
public class Aula_De_Java_Com_Dados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginFrame lf = new LoginFrame();
        lf.setVisible(true);
    }
    
}
