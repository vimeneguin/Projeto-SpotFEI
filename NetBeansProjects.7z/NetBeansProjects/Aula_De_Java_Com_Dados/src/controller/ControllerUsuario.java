/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import DAO.AlunoDAO;
import DAO.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Aluno;
import view.AltExcFrame;

/**
 *
 * @author unicvmeneguin
 */
public class ControllerUsuario {
    private AltExcFrame view;
    private Aluno aluno;

    public ControllerUsuario(AltExcFrame view, Aluno aluno) {
        this.view = view;
        this.aluno = aluno;
    }

    public void atualizar(){
        String nome = view.getLbl_nome_altexc().getText();
        String usuario = view.getLbl_usuario_altexc().getText();
        String senha = view.getLbl_senha_altexc().getText();
        Aluno aluno = new Aluno(nome, usuario, senha);
        Conexao conexao = new Conexao();
        try{
            Connection conn = conexao.getConnection();
            AlunoDAO dao = new AlunoDAO(conn);
            dao.atualizar(aluno);
            JOptionPane.showMessageDialog(view, "Atualizado com sucesso.");
        } catch (SQLException e){
            JOptionPane.showMessageDialog(view, "Erro de conexão.");
        }
    }
    
    public void remover(){
        String usuario = view.getLbl_usuario_altexc().getText();
        int option = JOptionPane.showConfirmDialog(view, "Deseja realmente excluir?", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        
        if (option !=1){
            Conexao conexao = new Conexao();
            try{
                Connection conn = conexao.getConnection();
                AlunoDAO dao = new AlunoDAO(conn);
                dao.remover(aluno);
                JOptionPane.showMessageDialog(view, "Excluido com sucesso.");
            } catch (SQLException e){
                JOptionPane.showMessageDialog(view, "Erro de conexão.");
            }
        }
    }
}
